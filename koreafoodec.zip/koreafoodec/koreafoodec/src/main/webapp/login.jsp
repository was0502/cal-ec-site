<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>

<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>ログイン</title>
  <link rel="stylesheet" href="${pageContext.request.contextPath}/style.css">
</head>
<body>
  <%@ include file="header-navi.jsp" %>

  <h2>ログイン</h2>

  <div class="login-container"> <!-- 로그인 폼을 감싸는 div 추가 -->
    <form action="login-servlet" method="post">
      ユーザーID: <input type="text" name="userId" required><br>
      パスワード: <input type="password" name="password" required><br><br>
      <input type="submit" value="ログイン">
    </form>

    <%
      String errorMsg = (String) request.getAttribute("errorMsg");
      if (errorMsg != null) {
    %>
      <p style="color:red;"><%= errorMsg %></p>
    <%
      }
    %>
  </div> <!-- div 종료 -->

  <footer class="site-footer">
    <p>© 2025 KOREA MARKET</p>
  </footer>
</body>
</html>
