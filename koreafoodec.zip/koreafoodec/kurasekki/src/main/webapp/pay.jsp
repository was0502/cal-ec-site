<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ page import="model.Cart" %>
<%@ page import="model.Product" %>
<%@ page import="java.util.ArrayList" %>
<%@ page import="java.util.List" %>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>決済完了</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
	<%@include file="header-navi.jsp"%>

	<h2>決済完了</h2>

	<p>お買い上げありがとうございます!</p>

	<%
		List<Product> listProd;
		Cart payData = (Cart) session.getAttribute("pay");
		if (payData == null) {
			listProd = new ArrayList<Product>();
		} else {
			listProd = payData.getListProd();
		}
		if (listProd.size() > 0) {
	%>
			<table class="pay-list">
			<tr>
				<th>商品 ID</th><th>商品名</th><th>価格</th>
			</tr>
	<%
			for (Product prod : listProd) {
	%>
				<tr>
					<td><%=prod.getId() %></td>
					<td><%=prod.getName() %></td>
					<td><%=prod.getPriceString() %>원</td>
				</tr>			
	<%
			}
	%>
			</table>
			<br>
			<p>合計支払金額: <%=payData.getTotalPriceString() %>원</p>

	<%
			session.removeAttribute("pay"); // 決済完了後のセッションから削除
		} 
	%>

</body>
</html>
