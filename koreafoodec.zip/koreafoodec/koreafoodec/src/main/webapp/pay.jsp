<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ page import="model.Cart" %>
<%@ page import="model.Product" %>
<%@ page import="java.util.ArrayList" %>
<%@ page import="java.util.List" %>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>決済完了</title>
<link rel="stylesheet" href="${pageContext.request.contextPath}/style.css">
</head>
<body>

  <%@ include file="header-navi.jsp" %>

  <h2>決済完了</h2>
  <p style="text-align: center; font-size: 24px; font-weight: bold;">
  ご購入いただき、ありがとうございます！
</p>

  <%
    List<Product> listProd;
    Cart payData = (Cart) session.getAttribute("pay");
    if (payData == null) {
      listProd = new ArrayList<Product>();
    } else {
      listProd = payData.getListProd();
    }
    if (listProd.size() > 0) {
  %>
    <table>
      <tr>
        <th>製品コード</th>
        <th>製品名</th>
        <th>価格 (円)</th>
      </tr>
      <%
        for (Product prod : listProd) {
      %>
        <tr>
          <td><%= prod.getId() %></td>
          <td><%= prod.getName() %></td>
          <td><%= prod.getPriceString() %></td>
        </tr>
      <%
        }
      %>
    </table>
    <br>
    <div class="total-price">
    <p>合計金額: <%= payData.getTotalPriceString() %> 円</p>
</div>

    <%
      // 決済完了後、セッションから削除
      session.removeAttribute("pay");
    }
  %>

  <footer class="site-footer">
    <p>© 2025 KOREA MARKET</p>
  </footer>

</body>
</html>
