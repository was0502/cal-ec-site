<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>KOREA MARKET</title>
  <link rel="stylesheet" href="${pageContext.request.contextPath}/style.css">
</head>
<body>

  <!-- 共通ヘッダー/ナビゲーション -->
  <%@ include file="header-navi.jsp" %>

  <!-- メインバナー -->
<section class="main-banner">
  <div class="banner-content">
	<nav class="category-nav">
	  <ul>
	    <li><a href="#">すべて</a></li>
	    <li><a href="#">ランキング</a></li>
	    <li><a href="#">ヘルプ</a></li>
	    <li><a href="#">ネットスーパー</a></li>
	  </ul>
	</nav>
  </div>
</section>

  <!-- プロモーション文言 -->
  <section class="promotion-section">
    <img src="https://kfood.zuikan.co.jp/mobile/img/event/m-201128kntv_event.jpg">
  </section>

  <!-- おすすめ商品 -->
  <section class="recommended-products">
    <h3>お客様にピッタリのおすすめ商品</h3>
    <div class="product-list">
      <div class="product-item">
        <img src="https://search.pstatic.net/common/?src=http%3A%2F%2Fshop1.phinf.naver.net%2F20240812_47%2F1723449578649rTV4g_PNG%2F50262473469605409_1838064814.png&type=sc960_832" alt="おすすめ商品1">
        <p class="product-name">ブルコギ</p>
        <p class="product-price">1,000円</p>
      </div>
      <div class="product-item">
        <img src="https://search.pstatic.net/common/?src=https%3A%2F%2Fshop-phinf.pstatic.net%2F20240627_55%2F17194544983816y720_JPEG%2F727941182294171_788536577.jpeg&type=sc960_832" alt="おすすめ商品2">
        <p class="product-name">キムチ 5kg</p>
        <p class="product-price">3,500円</p>
      </div>
      <div class="product-item">
        <img src="https://search.pstatic.net/common/?src=http%3A%2F%2Fblogfiles.naver.net%2FMjAyNDA5MDZfNjgg%2FMDAxNzI1NjE1NzY0NDM4.4fvNau0WYxedPk1G83amnKw5KdPyvWTTPzt04TL4epEg.zBcu3a4e7lKy9We_Rp5LJtEbSNUGBcUa668Cj7Omgb8g.JPEG%2F%25B1%25E8%25B9%25E4-6_-_1.jpg&type=sc960_832" alt="おすすめ商品3">
        <p class="product-name">キンパ</p>
        <p class="product-price">600円</p>
      </div>
    </div>
  </section>

  <!-- フッター -->
  <footer class="site-footer">
    <p>© 2025 KOREA MARKET</p>
  </footer>

</body>
</html>
