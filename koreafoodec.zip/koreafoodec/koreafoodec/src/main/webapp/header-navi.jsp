<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>

<header class="site-header">
  <div class="header-inner">
    <!-- ロゴ -->
    <h1 class="logo">
  <a href="${pageContext.request.contextPath}/index.jsp">
    <span style="font-size: 40px; font-weight: bold; color: #333;">KOREA MARKET</span>
  </a>
</h1>

    <!-- 検索ボックス（例） -->
<div class="search-box">
    <input type="text" placeholder="検索キーワードを入力" name="q" required />
    <button type="submit">検索</button>
</div>

    <!-- ナビゲーションメニュー -->
    <nav class="nav-menu">
      <a href="${pageContext.request.contextPath}/select.jsp">商品選択</a>
      <a href="${pageContext.request.contextPath}/cart.jsp">カート</a>
      <a href="${pageContext.request.contextPath}/login.jsp">ログアウト</a>
    </nav>
  </div>
</header>
