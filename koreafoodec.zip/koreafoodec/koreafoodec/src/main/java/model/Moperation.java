package model;

import java.util.ArrayList;

import jakarta.servlet.http.HttpSession;

public class Moperation {

	public boolean loginProc(String userId, String password, HttpSession session) {
		boolean result = authenticate(userId, password);
		if (result) {
			Store store = makeStore();
			session.setAttribute("store", store);
			
			Cart cart = new Cart(userId, new ArrayList<Product>());
			session.setAttribute("cart", cart);
		}
		return result;
	}

	private boolean authenticate(String userId, String password) {
		return password.equals("pass");
	}

	private Store makeStore() {
		Store store = new Store("韓食堂", new ArrayList<Product>());

		// 상대 경로를 "/images/xxx.jpg"로 통일
		store.add(new Product("A110", "ビビゴ 王餃子", 1995, "/images/product01.jpg"));
		store.add(new Product("A120", "ユッケジャン正規品", 2871, "/images/product02.jpg"));
		store.add(new Product("A130", "カンナムチョッパル", 1920, "/images/product03.jpg"));
		store.add(new Product("A140", "チュクミ 350g X 1個 ", 1112, "/images/product04.jpg"));
		store.add(new Product("A150", "コレオロジーカットゼリー", 2680, "/images/product05.jpg"));
		store.add(new Product("A160", "釜山四角おでん", 1900, "/images/product06.jpg"));
		store.add(new Product("A170", "ビヨット×３種類＋トッピン×３種類", 2900, "/images/product07.jpg"));
		store.add(new Product("A180", "純米 トッポギ 600g", 559, "/images/product08.jpg"));
		store.add(new Product("A190", "韓チャパゲティ 5袋", 1177, "/images/product09.jpg"));
		store.add(new Product("A200", "テジクッパ (1人前x4個)", 4280, "/images/product10.jpg"));

		return store;
	}

	public void logoutProc(HttpSession session) {
		session.invalidate();
	}

	public void addProd(int idx, HttpSession session) {
		Store store = (Store) session.getAttribute("store");
		Cart cart = (Cart) session.getAttribute("cart");

		if ((store != null) && (cart != null)) {
			cart.add(store.getListProd().get(idx));
			session.setAttribute("cart", cart);
		}
	}

	public void removeProd(int idx, HttpSession session) {
		Cart cart = (Cart) session.getAttribute("cart");
		if (cart != null) {
			cart.remove(idx);
			session.setAttribute("cart", cart);
		}
	}

	public void pay(HttpSession session) {
		Cart cart = (Cart) session.getAttribute("cart");
		if (cart != null) {
			session.setAttribute("pay", cart);
			Cart newCart = new Cart(cart.getUserId(), new ArrayList<Product>());
			session.setAttribute("cart", newCart);
		}
	}
}
