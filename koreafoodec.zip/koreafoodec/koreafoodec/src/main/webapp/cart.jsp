<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ page import="model.Cart" %>
<%@ page import="model.Product" %>
<%@ page import="java.util.ArrayList" %>
<%@ page import="java.util.List" %>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>カート</title>
<link rel="stylesheet" href="${pageContext.request.contextPath}/style.css">
</head>
<body>

  <%@ include file="header-navi.jsp" %>

  <h2>カート</h2>

  <%
    List<Product> listProd;
    Cart cart = (Cart) session.getAttribute("cart");
    if (cart == null) {
      listProd = new ArrayList<Product>();
    } else {
      listProd = cart.getListProd();
    }
    if (listProd.size() > 0) {
  %>
    <table>
  <tr>
    <th></th>
    <th>製品コード</th>
    <th>製品名</th>
    <th>価格 (円)</th>
  </tr>
  <%
    for (int idx = 0; idx < listProd.size(); idx++) {
      Product prod = listProd.get(idx);
  %>
    <tr>
      <td>
        <form action="remove-prod-servlet" method="POST">
          <input type="hidden" name="idx" value="<%= idx %>">
          <input type="submit" value="削除">
        </form>
      </td>
      <td><%= prod.getId() %></td>
      <td><%= prod.getName() %></td>
      <td><%= prod.getPriceString() %></td>
    </tr>
  <%
    }
  %>
</table>

    <br>
    <form action="pay-servlet" method="post">
      <input type="submit" class="btn-submit" value="決済へ進む">
    </form>
  <%
    } else {
  %>
    <p>カートは空です。</p>
  <%
    }
  %>

  <footer class="site-footer">
    <p>© KOREA MARKET</p>
  </footer>

</body>
</html>
